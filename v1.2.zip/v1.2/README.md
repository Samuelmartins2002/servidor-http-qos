# Servidor HTTP com QoS — Versão 1 (MVP)

Fundamentos e Avaliação de Redes de Computadores — 2026/2

## Equipe
- Simony Meira Franco Cogoy da Silva
- João Pedro Soll Dias
- Samuel Martins da Silva

## Compilação e execução
Requisitos: Linux, `gcc`, `make`.

```bash
make
./servidor [porta] [diretorio_raiz]    # padrão: porta 8080, raiz ./www
```

Exemplos de teste:
```bash
# duas requisições na MESMA conexão (prova do keep-alive)
curl --http1.1 -v -o /dev/null -o /dev/null http://localhost:8080/ http://localhost:8080/img1.png

# vários clientes simultâneos
for i in 1 2 3 4 5; do curl -s -o /dev/null http://localhost:8080/img1.png & done; wait
```

## Funcionalidades da V1
- Uma thread Pthreads por conexão (`pthread_detach`), vários clientes simultâneos.
- HTTP/1.1 com conexões persistentes (keep-alive); HTTP/1.0 fecha após a resposta.
- Cabeçalho `Connection: close` respeitado; timeout de ociosidade de 15 s; máx. de 100 requisições por conexão.
- Métodos GET e HEAD; demais métodos retornam 405.
- Respostas 200, 400, 404, 405, 505, com `Content-Length` e `Content-Type`.
- Proteção contra path traversal (`..`, inclusive `%2e%2e`).
- Envio de arquivos em blocos de 4 KB (ponto onde o controle de taxa entrará na V2).
- Log de conexões e requisições na saída padrão.

## Observações
- A pasta `www/` contém `index.html` e 3 imagens de ~4 MB (`img1..3.png`, ruído aleatório) para os testes.
- Ainda **não** implementado (previsto para a V2): controle de taxa por IP, estimativa de RTT/banda, visualização em tempo real e controle de admissão.

## Declaração
Este projeto foi desenvolvido integralmente pela equipe, sem ajuda não autorizada de alunos não membros do projeto no processo de codificação.

**Uso de IA:** o código de `servidor.c` (versão final da V1) foi produzido com apoio do assistente de IA Claude (Anthropic), a partir do exemplo básico de sockets da própria equipe, e revisado/testado pelos integrantes. Isso também está indicado no cabeçalho do código-fonte e no relatório.
